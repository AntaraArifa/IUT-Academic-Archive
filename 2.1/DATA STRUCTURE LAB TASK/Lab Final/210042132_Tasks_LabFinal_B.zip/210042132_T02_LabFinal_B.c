#include <iostream>
#include <stack>
#include <string>

using namespace std;

bool checkParenthesis(const string & expression)
{
    stack<char> st;

    for (char c : expression)
    {
        if(c == '(' || c == '{' || c == '[')
            {
                st.push(c);
            }
        else if(c == ')' || c == '}' || c == ']')
            {
                if(st.empty() || (c == ')' && st.top != '(') || (c == ']' && st.top != '[') || (c == '}' && st.top != '{') )
                    {
                        return false;
                    }

                    st.pop();

            }

    }
    return st.empty();
}

int main()
{
    int t;
    cin >> t;

    for(int i= 0; i<t; i++)
    {
        string expression;
        getline(cin,expression);

        string cleanexpression;

        for(char c : expression)
        {
            if(c!= ' ')
            {
                cleanexpression += c;
            }
        }

        if(checkParenthesis(cleanexpression))
        {
            cout << "YES";
        }
        else
        {
            cout << "NO";
        }
    }
    return 0;
}
