import java.util.List;
public class Main {
    public static  void main(String[] args) {
        List<employee> employees = new employeeReader().readEmployees();

        employeeUtils emputil = new employeeUtils();

        System.out.println("2. Employees with age >= 30:");
        emputil.groupByAge(employees, 30);

        System.out.println("\n\n");

        System.out.println("3. Employees grouped by postal code:");
        emputil.groupByCode(employees);

        System.out.println("\n\n");

        System.out.println("4. Average remuneration:");
        emputil.avgRemuneration(employees);

        System.out.println("\n\n");

        System.out.println("5. Highest remuneration:");
        emputil.highestRemuneration(employees);

        System.out.println("\n\n");

        if(emputil.checkManager(employees))
        {
            System.out.println("6. There is a manager");
        }
        else
        {
            System.out.println("6. There is no manager");
        }

        System.out.println("\n\n");

        System.out.println("7. Sort by age:");
        emputil.sortByAge(employees);

        System.out.println("\n\n");

        System.out.println("8. Youngest employee:");
        emputil.findYoungestEmployee(employees);

        System.out.println("\n\n");

        System.out.println("9. Uptown employees:");
        emputil.countUptown(employees);

        System.out.println("\n\n");

        System.out.println("10. Distinct postal codes:");
        emputil.printDistinctPostalCode(employees);

        System.out.println("\n\n");

        System.out.println("11. Total cost of remuneration:");
        emputil.totalCostOfRemuneration(employees);

        System.out.println("\n\n");

        System.out.println("12. Adult employee count:");
        emputil.adultEmployeesCount(employees);

        System.out.println("\n\n");

        System.out.println("13. Skipping 3 employees:");
        emputil.skip3Employees(employees);

        System.out.println("\n\n");

        System.out.println("14. Average age in downtown:");
        emputil.avgAgeDowntown(employees);

        System.out.println("\n\n");

        System.out.println("15. Top 3 remunerations:");
        emputil.top3Remuneration(employees);

        System.out.println("\n\n");








    }
}