import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class employeeUtils {

    // Prints employees with age >= age
    public void groupByAge(List<employee> e, int age){
        for(employee employee: e){
            if(employee.age >= age){
                System.out.println(employee.firstName + " " + employee.lastName + " - " + employee.age);
            }
        }
    }

    // Prints employees grouped by postal code
    public void groupByCode(List<employee> e){
        Map<String, List<employee>> employeesByPostalCode = e.stream()
                .collect(Collectors.groupingBy(employee::getPostCode));

        employeesByPostalCode.forEach((postalCode, employeeList) -> {
            System.out.println("Postal Code: " + postalCode);
            employeeList.forEach(employee -> System.out.println(employee.firstName + " " + employee.lastName));
            System.out.println("------");
        });
    }

    // Prints the average remuneration of employees
    public void avgRemuneration(List<employee> e){
        double sum = 0;
        for (employee employee : e){
            sum += employee.remuneration;
        }
        System.out.println("Avarage remuneration : " + sum / e.size());
    }

    // Prints the employee with the highest remuneration
    public void highestRemuneration(List<employee> e){
        double highest = 0;
        employee emp = null;
        for (employee employee : e){
            if (employee.remuneration > highest){
                highest = employee.remuneration;
                emp = employee;
            }
        }
        System.out.println("Highest remuneration : " + emp.firstName + " " + emp.lastName + " - " + emp.remuneration);
    }

    // Checks if there is a manager
    public boolean checkManager(List<employee> e){
        for (employee employee : e){
            if (employee.designation.equals("Manager")){
                return true;
            }
        }
        return false;
    }

    // Sorts the list of employees by age in ascending order
    public void sortByAge(List<employee> e){
        for(int i=0; i < e.size(); i++){
            for(int j=0; j < e.size() - 1; j++){
                if(e.get(j).age > e.get(j+1).age){
                    employee temp = e.get(j);
                    e.set(j, e.get(j+1));
                    e.set(j+1, temp);
                }
            }
        }
        System.out.println("Sorted by age in ascending order");
    }

    // Prints the youngest employee
    public void findYoungestEmployee(List<employee> e){
        sortByAge(e);
        System.out.println("Youngest employee: " + e.get(0).firstName + " " + e.get(0).lastName + " - " + e.get(0).age);
    }

    // Counts the number of employees working in Uptown district
    public void countUptown(List<employee> e){
        int count = 0;
        for (employee employee : e){
            if (employee.district.equals("Uptown")){
                count++;
            }
        }
        System.out.println("Number of employees working in Uptown district: " + count);
    }

    // Prints district postal codes
    public void printDistinctPostalCode(List<employee> e){
        List<String> distinctPostalCodes = e.stream()
                .map(employee::getPostCode)
                .distinct()
                .collect(Collectors.toList());

        System.out.println("Distinct postal codes: " + distinctPostalCodes);
    }

    // Prints the total cost of remuneration
    public void totalCostOfRemuneration(List<employee> e){
        double total = 0;
        for (employee employee : e){
            total = total + employee.remuneration;
        }
        System.out.println("Total cost of remuneration: " + total);
    }

    // Prints the number of adult employees
    public void adultEmployeesCount(List<employee> e){
        int count = 0;
        for (employee employee : e){
            if (employee.age >= 18){
                count++;
            }
        }
        System.out.println("Number of adult employees: " + count);
    }


    // Prints the avarage age of employees working in Downtown district
    public void avgAgeDowntown(List<employee> e){
        int sum = 0;
        int count = 0;
        for (employee employee : e){
            if (employee.district.equals("Downtown")){
                sum += employee.age;
                count++;
            }
        }
        System.out.println("Avarage age of employees working in Downtown district: " + sum / count);
    }

    // Prints the top 3 employees with the highest remuneration
    public void top3Remuneration(List<employee> e){
        for(int i=0; i < e.size(); i++){
            for(int j=0; j < e.size() - 1; j++){
                if(e.get(j).remuneration < e.get(j+1).remuneration){
                    employee temp = e.get(j);
                    e.set(j, e.get(j+1));
                    e.set(j+1, temp);
                }
            }
        }
        System.out.println("Top 3 employees with the highest remuneration: ");
        for(int i=0; i < 3; i++){
            System.out.println(e.get(i).firstName + " " + e.get(i).lastName + " - " + e.get(i).remuneration);
        }
    }

    // Skips the first 3 employees and prints the rest
    public void skip3Employees(List<employee> e){
        System.out.println("Employees after skipping the first 3: ");
        e.stream()
                .skip(3)
                .forEach(employee -> System.out.println(employee.firstName + " " + employee.lastName));
    }


}
