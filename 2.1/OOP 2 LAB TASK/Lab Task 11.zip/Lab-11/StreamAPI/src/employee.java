public class employee {
    public String firstName;
    public String lastName;
    public String postCode;
    public String street;
    public String district;
    public int age;
    public String designation;
    public double remuneration;

    public employee(String firstName, String lastName, String postCode, String street, String district, int age, String designation, double remuneration)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.postCode = postCode;
        this.street = street;
        this.district = district;
        this.age = age;
        this.designation = designation;
        this.remuneration = remuneration;
    }

    public String getPostCode()
    {
        return postCode;
    }

}
