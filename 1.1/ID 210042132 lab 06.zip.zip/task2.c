#include<stdio.h>
int main()
{
    int i,a,b,c;
    printf("Enter two integers: ");
    scanf("%d %d",&a,&b);

    for(i=1;i<=a && i<=b;i++)
    {
        if(a%i==0 && b%i==0)
            c=i;
    }
    printf("Greatest common divisor: %d",c);
    return 0;

}
