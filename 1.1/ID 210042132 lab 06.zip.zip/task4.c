#include<stdio.h>
int main()
{
    float c,v;
    printf("Enter value of trade:");
    scanf("%f",&v);

    while(v>0)
    {
       if(v<2500)
       {
           c=30+.017f*v;
       }
       else if(v>=2500 && v<6250)
       {
           c=56+.0066f*v;
       }
       else if(v>=6250 && v<20000)
       {
           c=76+.0034f*v;
       }
       else if(v>=20000 && v<50000)
       {
           c=100+.0022f*v;
       }
       else if(v>=50000 && v<50000)
       {
           c=155+.0011f*v;
       }
       else
       {
           c=255+.0009*v;
       }
       if(c<39)
       {
           c=39;
       }

       printf("Commission: $%.2f\n",c);
       printf("Enter value of trade:");
       scanf("%f",&v);
    }
    return 0;
}
