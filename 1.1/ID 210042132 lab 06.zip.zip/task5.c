# include  <stdio.h>
int main()
{
    int n;
    scanf("%d",&n);

    if(n==1)
    {
        printf("*");
    }
    else
    {
        int k=n;

        for(int i=0;i<=n-1;i++)
        {
              int p=(2*i)+1;

              for(int l=1;l<=k;l++)
              {
                  printf(" ");
              }

              for(int j=1;j<=p;j++)
              {
                  printf("*");
              }

              for(int l=1;l<=k;l++)
              {
                  printf(" ");
              }
              printf("\n");

            k=k-1;


        }
        int p;
        if(n%2==0)
        {
            p=n-1;
        }
        else
        {
            p=n;
        }

        int h=2*(n-1)+1;

        int g=(h-p)/2;

        for(int i=1;i<=n;i++)
        {
            for(int i=1;i<=g+1;i++)
            {
                printf(" ");
            }
            for(int i=1;i<=p;i++)
            {
                printf("*");
            }
            for(int i=1;i<=g+1;i++)
            {
                printf(" ");
            }
            printf("\n");
        }
    }

}
