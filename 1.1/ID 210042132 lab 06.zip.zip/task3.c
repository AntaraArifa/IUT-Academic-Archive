#include<stdio.h>
int main()
{
    int i,a,b,c,d,e;
    printf("Enter a fraction: ");
    scanf("%d/%d",&a,&b);

    for(i=1;i<=a && i<=b;i++)
    {
        if(a%i==0 && b%i==0)
        {
            c=i;
        }
    }
    printf("In lowest terms: %d/%d",a/c,b/c);
    return 0;
}

