#include<stdio.h>
int main()
{
    float n,l=0.0f;
    do
    {
        printf("Enter a number: ");
        scanf("%f",&n);

        if(n>l)
        {
            l=n;
        }
    }
        while(n>0);
            printf("The largest number entered was %.2f\n",l);

            return 0;

}
