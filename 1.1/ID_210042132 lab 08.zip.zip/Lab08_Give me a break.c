#include <stdio.h>
int main()
{
    int n;
    printf("Enter the value of n: ");
    scanf("%d",&n);
    getchar();
    int count=0;

    for(int i=2; i<=n; i=i+2)
    {
        printf("%d ",i*i);
        count++;
        if(count%24==0)
        {
            printf("\n\Press enter to continue...\n");
            char c=getchar();

        }
    }
}
