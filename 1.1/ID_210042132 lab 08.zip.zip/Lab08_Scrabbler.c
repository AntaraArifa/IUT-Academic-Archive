#include <stdio.h>
#include <ctype.h>
int main()
{
    char word;
    int ans = 0;

    printf("Enter a word: ");

    while ((word = getchar())!= '\n')
    {

        switch (toupper(word))
        {
        case 'A':
        case 'E':
        case 'I':
        case 'L':
        case 'N':
        case 'O':
        case 'R':
        case 'S':
        case 'T':
        case 'U':
            ans = ans + 1;
            break;
        case 'D':
        case 'G':
            ans = ans + 2;
            break;
        case 'B':
        case 'C':
        case 'M':
        case 'P':
            ans = ans + 3;
            break;
        case 'F':
        case 'H':
        case 'V':
        case 'W':
        case 'Y':
            ans = ans + 4;
            break;
        case 'K':
            ans = ans + 5;
            break;
        case 'J':
        case 'X':
            ans = ans + 8;
            break;
        case 'Q':
        case 'Z':
            ans = ans + 10;
            break;
        }
    }

    printf("Scrabble ans: %d\n", ans);

    return 0;
}
