#include<stdio.h>
int main()
{
    double n, sum=0;
    printf("Enter number: ");
    while(1)
    {
        scanf("%lf", &n);
        if(n<=0)
        break;
        sum = sum+n;
    }
    printf("%lf", sum);

return 0;
}
