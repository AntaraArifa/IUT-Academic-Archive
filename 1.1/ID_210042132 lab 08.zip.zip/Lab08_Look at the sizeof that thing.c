#include<stdio.h>
int main()
{

    printf("Sizeof(int)              : %d\n", sizeof(int));
    printf("Sizeof(short)            : %d\n", sizeof(short));
    printf("Sizeof(long)             : %d\n", sizeof(long));
    printf("Sizeof(long long)        : %d\n", sizeof(long long));
    printf("Sizeof(float)            : %d\n", sizeof(float));
    printf("Sizeof(double)           : %d\n", sizeof(double));
    printf("Sizeof(long long double) : %d\n", sizeof(long double));
}
