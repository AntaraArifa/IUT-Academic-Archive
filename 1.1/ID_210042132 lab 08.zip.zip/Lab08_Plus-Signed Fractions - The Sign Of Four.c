#include<stdio.h>
int main()
{
    int n1,d1,n2,d2;
    int numerator, denominator;
    char sign;

    printf("Enter 2 fraction and desired operartion\n");
    scanf("%d/%d %c %d/%d", &n1, &d1, &sign, &n2, &d2);

    if(sign == '+')
    {
        denominator = d1*d2;
        numerator = (d2*n1)+(d1*n2);
        printf("\nSum = %d/%d\n", numerator, denominator);
    }

    else if(sign == '-')
    {
        denominator = d1*d2;
        numerator = (d2*n1)-(d1*n2);
        printf("\nSubstraction = %d/%d\n", numerator, denominator);
    }
    else if(sign == '*')
    {
        numerator = n1*n2;
        denominator = d1*d2;
        printf("\nMultiplication = %d/%d\n",numerator, denominator);
    }
    else if(sign == '/')
    {
        denominator = n1*d2;
        numerator = n2*d1;
        printf("\nDivision = %d/%d\n",numerator, denominator);
    }

    return 0;
}
