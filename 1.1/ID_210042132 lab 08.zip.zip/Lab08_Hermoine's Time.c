#include<stdio.h>
int main()
{
    int h, m;
    char c1, c2;

    printf("Enter a 12-hour time: ");
    scanf("%d:%d %c%c", &h, &m, &c1, &c2);

    if(c1 == 'A' || c1 == 'a')
    {
        if(h==12)
        {
            printf("Equivalent 24-hour time: 00:%0.2d",m);
        }
        else
        {
            printf("Equivalent 24-hour time: %0.2d:%0.2d",h, m);
        }

    }
    else if(c1 == 'P' || c1 == 'p')
    {

            h = h+12;
            printf("Equivalent 24-hour time: %0.2d:%0.2d",h, m);

    }
}
