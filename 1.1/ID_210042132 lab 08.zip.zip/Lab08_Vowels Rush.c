#include<stdio.h>
int main()
{
    char c;
    int count = 0;

    printf("Enter a sentence: ");

    while(c!='.')
    {
        scanf("%c",&c);
        if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||c=='A'||c=='E'||c=='I'||c=='O'||c=='U')
        {
            count++;
        }
    }
    printf("\nYour sentence contains %d vowels.\n",count);

    return 0;
}
