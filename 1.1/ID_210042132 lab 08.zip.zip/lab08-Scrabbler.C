#include<stdio.h>
#include<ctype.h>
int main()
{
    char c;
    int sum=0;
    printf("Enter a word:");

    while ((c= getchar())!= '\n'){


    switch (toupper (c))
    {
        case 'A': case 'E': case 'I': case 'L': case 'N': case 'O': case 'R': case 'S': case 'T': case 'U':
            {
              sum=sum+1;
              break;
            }
        case 'D': case 'G':
            {
              sum=sum+2;
              break;
            }
        case 'B': case 'C': case 'M': case 'P':
            {
              sum=sum+3;
              break;
            }
        case 'F': case 'H': case 'V': case 'W': case 'Y':
            {
              sum=sum+4;
              break;
            }
        case 'K':
            {
              sum=sum+5;
              break;
            }
        case 'J': case 'X':
            {
              sum=sum+8;
              break;
            }
        case 'Q': case 'Z':
        {
            sum=sum+10;
            break;
        }
    }
    }
    printf("Scrabble value: %d",sum);
    return 0;
}

