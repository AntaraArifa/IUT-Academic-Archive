#include<stdio.h>
int main()
{
    char c;
    float spct=0,ct=0,tot,avg;

    printf("Enter a sentence: ");

    while(c!='.')
    {
        scanf("%c",&c);

        if(c==' ')
        {
            spct=spct+1;
        }
        else
        {
            ct=ct+1;
        }
    }

    tot = spct + 1;

    ct = ct - 1;

    avg = ct/tot;

    printf("\n\nAvg leanth : %f",avg);


    return 0;
}
