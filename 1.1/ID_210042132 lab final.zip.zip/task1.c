#include<stdio.h>
#include<string.h>
int main ()
{
    int widths[1000],sum1=0,res_1,res_2=0,i;
    char s[];
    int len=strlen(s);

    for(i=0;i<widths;i++)
    {
        scanf("%d",&widths[i]);
        gets(s);
        sum1=sum1+widths[i];
        if(widths<=100)
        {
            res_1++;
        }
    }


    return 0;
}
