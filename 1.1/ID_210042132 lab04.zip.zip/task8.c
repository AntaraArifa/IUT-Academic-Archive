#include<stdio.h>
int main()
{
  int a,b;
  printf("Enter the first integer : ");
  scanf("%d",&a);
  printf("Enter the second integer : ");
  scanf("%d",&b);
  a=a+b;
  b=a-b;
  a=a-b;
  printf("Swapping the first integer : %d\n",a);
  printf("Swapping the second integer : %d",b);

return 0;
}

