#include<stdio.h>
int main()
{
  int a,b,temp;
  printf("Enter the first integer : ");
  scanf("%d",&a);
  printf("Enter the second integer : ");
  scanf("%d",&b);
  temp=a;
  a=b;
  b=temp;
  printf("Swapping the first integer : %d\n",a);
  printf("Swapping the second integer : %d",b);

return 0;
}
