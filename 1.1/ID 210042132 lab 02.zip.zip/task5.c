#include <stdio.h>
int main ()
{

    float d,r,v;
    float pi= 3.14159;
    d=20;
    r=d/2;
    v=4.0f/3.0f*pi*r*r*r;
    printf("Volume of the sphere is = %f",v);
    return 0;
}
