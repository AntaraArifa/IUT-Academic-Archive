#include<stdio.h>
int main()
{

int x;
printf ("enter the value of x=");
scanf("%d",&x);
int k,l,m,n;
k=x/20;
l=(x-(20*k))/10;
m=(x-(20*k)-(10*l))/5;
n=(x-(20*k)-(10*l)-(5*m))/1;

printf("$20 bills:%d\n",k);
printf("$10 bills:%d\n",l);
printf("$ 5 bills:%d\n",m);
printf("$ 1 bills:%d\n",n);

 return 0;
}
