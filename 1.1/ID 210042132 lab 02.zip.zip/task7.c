#include <stdio.h>

int main ()
{

    double x,e;
    printf("Enter value of x= ");
    scanf("%lf", &x);
    e=(((((3*x+2)*x-5)*x-1)*x+7)*x-6);
    printf("Evaluation of the formula is=%lf", e);
    return 0;
}
