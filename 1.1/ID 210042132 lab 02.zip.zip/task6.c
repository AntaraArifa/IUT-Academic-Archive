#include <stdio.h>

int main ()
{

float a,t;
printf("Enter an amount= ");
scanf("%f", &a);
t= a+a*5/100;
printf ("Total amount including VAT= %f", t);
return 0;
}
