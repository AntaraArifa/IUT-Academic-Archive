#include<stdio.h>
int main()
{

    int radius=10;
    float pi=3.14159;
    printf("radius=");
    scanf ("%d",&radius);
    float volume=(4.0f/3.0f)*pi*(radius*radius*radius);
    printf("volume=%f",volume);
    return 0;
}
