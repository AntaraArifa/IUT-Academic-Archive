#include<stdio.h>

int main()
{

    float l, R, p, r, x, y, z;
    printf("Enter amount of loan=");
    scanf("%f", &l);
    printf("Enter interest rate=");
    scanf("%f", &R);
    printf("Enter monthly payment=");
    scanf("%f", &p);
    r=R/12;
    x= l-p+(l*r/100);
    y= x-p+(x*r/100);
    z= y-p+(y*r/100);

    printf("Balance remaining after first payment= %.2f\n", x);

    printf("Balance remaining after second payment= %.2f\n", y);

    printf("Balance remaining after third payment= %.2f\n", z);

    return 0;

}
