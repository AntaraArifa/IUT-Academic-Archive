#include<stdio.h>

int main(){


    int a[5][5];
    int i,j;
    for(i=0;i<5;i++){
        printf("Enter row %d: ",i+1);
        for(j=0;j<5;j++)
        scanf("%d",&a[i][j]);
    }

    printf("Row total: ");
    for(i=0;i<=5;i++){
            int sum=0;
        for(j=0;j<=5;j++){
            sum=sum+a[i][j];
        }

    printf("%d ",sum);
    }

    for(i=0;i<=5;i++){
         int sum=0;
        for(j=0;j<=5;j++){
            sum=sum+a[j][i];
        }
        printf("Column total:%d ",sum);
    }











    return 0;


}
