#include <stdio.h>

#define NUM_RATES ((int) (sizeof(value) / sizeof(value[0])))
#define INITIAL_BALANCE 100.00

int main(void)
{
    int i, lr, ny, month, year;
    double value[5];

    printf("Enter interest rate: ");
    scanf("%d", &lr);
    printf("Enter number of years: ");
    scanf("%d", &ny);

    printf("\nYears");
    for (i = 0; i < NUM_RATES; i++)
    {
        printf("%6d%%", lr + i);
        value[i] = INITIAL_BALANCE;
    }
    printf("\n");

    for (year = 1; year <= ny; year++)
    {
        printf("%3d    ", year);
        for (i = 0; i < NUM_RATES; i++)
        {
            for (month = 1; month <= 12; month++)
            {
                value[i] += ((lr + i) / 100.0 / 12) * value[i];
            }
            printf("%7.2f", value[i]);
        }
        printf("\n");
    }
    printf("\n");

    return 0;
}
