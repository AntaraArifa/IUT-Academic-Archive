
#include<stdio.h>
#define n 100

int main()
{
    char a[50], input;
    int i;
    printf("Enter message: ");

    for(i=0; i<50; i++)
    {
        switch(input=toupper(getchar()))
        {
            case 'A': a[i]='4';
                break;
            case 'B': a[i]='8';
                break;
            case 'E': a[i] = '3';
                break;
            case 'I': a[i] = '1';
                break;
            case 'O': a[i] = '0';
                break;
            case 'S': a[i] = '5';
                break;
            default: a[i] = input;
        }
        if (input == '\n')
            break;
    }

    printf("In B1FF-speak: ");
    for (i = 0; i < 50; i++)
    {
        if (a[i] == '\n')
            break;
        putchar(a[i]);
    }
    printf("!!!!!!!!!!\n\n");

    return 0;
}
