#include<stdio.h>


int main(){

        long n,i,digit;
        int repeated[10]={0};

        printf("Enter a number: ");
        scanf("%ld",&n);
        while(n>0){
            digit=n%10;
            repeated[digit]++;
            n=n/10;
        }


            for(i=0;i<10;i++){
                if(repeated[i]>1){
                    printf("%d ",i);
                }
            }









        return 0;



}
