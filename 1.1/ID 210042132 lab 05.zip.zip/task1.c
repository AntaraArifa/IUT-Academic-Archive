#include<stdio.h>
int main ()
{
    int a;
    printf("Enter a number :");
    scanf("%d",&a);

    if(a>=0 && a<=9)
    {
        printf("The number %d has one digit",a);
    }
    else if(a>=10 && a<=99)
    {
        printf("The number %d has two digits",a);
    }

    else if(a>=100 && a<=999)
    {
        printf("The number %d has three digits",a);
    }
    else if(a>=1000 && a<=9999)
    {
        printf("The number %d has four digits",a);
    }
    return 0;
}
