#include<stdio.h>
int main ()
{
  int a;
    printf("Enter a wind Speed(in knots):");
    scanf("%d",&a);

    if(a<1)
    {
        printf("Calm");
    }
    else if(a<=3)
    {
        printf("Light air");
    }
    else if(a<=27)
    {
        printf("Breeze");
    }
    else if(a<=47)
    {
        printf("Gate");
    }
    else if(a<=63)
    {
        printf("Storm");
    }
    else
    {
        printf("Hurricane");
    }
    return 0;
}
