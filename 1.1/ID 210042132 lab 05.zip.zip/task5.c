#include <stdio.h>
int main()
{
    int n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,sum1,sum2,total,rem;
    printf("Enter the first 11 digits of a UPC : ");
    scanf("%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d",&n1,&n2,&n3,&n4,&n5,&n6,&n7,&n8,&n9,&n10,&n11,&n12);
    sum1=n1+n3+n5+n7+n9+n11;
    sum2=n2+n4+n6+n8+n10;
    total=(3*sum1+sum2)-1;
    rem=total%10;

    if(n12==(9-rem))
    {
        printf("VALID");
    }
    else
    {
        printf("NOT VALID");
    }
    return 0;
}



