#include<stdio.h>
int main()
{
    int hour,min;
    printf("Enter a 24-hour time:");
    scanf("%d:%d",&hour,&min);

    if(hour>12 && hour<23)
    {
        printf("Equivalent 12-hour time:%d:%.2d PM",hour-12,min);
    }

    else if(hour==12)
    {
        printf("Equivalent 12-hour time:%d:%.2d PM", hour,min);
    }
    else if(hour==24)
    {
        printf("Equivalent 12-hour time:%d:%.2d AM", hour-12,min);
    }
    else
    {
        printf("Equivalent 12-hour time:%d:%.2d AM",hour,min);
    }

    return 0;
}
