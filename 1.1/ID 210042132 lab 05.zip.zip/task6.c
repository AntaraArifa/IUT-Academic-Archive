#include<stdio.h>
int main()
{
    float a;
    printf("Enter the amount of taxable income :");
    scanf("%f",&a);

    if(a<750)
    {
        printf("Due Tax $%.2f",.01f*a);
    }
    else if(a>=750 && a<2250)
    {
        printf("Due Tax $%.2f",7.50f+(.02f*(a-750)));
    }
    else if(a>=2250 && a<3750)
    {
        printf("Due Tax $%.2f",37.50f+(.03f*(a-2250)));
    }
    else if(a>=3750 && a<5250)
    {
        printf("Due Tax $%.2f",82.50f+(.04f*(a-3750)));
    }
    else if(a>=5250 && a<7000)
    {
        printf("Due Tax $%.2f",142.50f+(.05f*(a-5250)));
    }
    else if(a>7000)
    {
        printf("Due Tax $%.2f",230.00f+(.06f*(a-7000)));
    }
    return 0;

}
