#include<stdio.h>
int main()
{
    float c;
    printf("Enter value of trade:");
    scanf("%f",&c);
    if(c<2500)
    {
        printf("Commission: $%.2f",30+.017f*c);
    }
    else if(c<6250)
    {
        printf("Commission: $%.2f",56+.0066f*c);
    }
    else if(c<20000)
    {
        printf("Commission: $%.2f",76+.0034f*c);
    }
    else if(c<50000)
    {
        printf("Commission: $%.2f",100+.0022f*c);
    }
    else if(c<500000)
    {
        printf("Commission: $%.2f",155+.0011f*c);
    }
    else if(c>500000)
    {
        printf("Commission: $%.2f",255+.0009f*c);
    }

    int s,p;
    printf("\nEnter number of shares :");
    scanf("%d",&s);
    printf("Enter price per share :");
    scanf("%d",&p);

    if (s<2000)
    {
        printf("Commission by rival broker: $%.2f",33+.03f*s*p);
    }
    else
    {
        printf("Commission by rival broker: $%.2f",33+.02f*s*p);
    }
       return 0;
}
