#include <stdio.h>

int polynomial(int x)
{

    return (2*x*x*x*x*x*x*x)+(1*x*x*x*x*x*x)-(4*x*x*x*x*x)-(2*x*x*x*x)+(x*x*x)-(3*x*x)+(2*x)+10;

}

int polynomial(int x);

int main()
{

    int x;
    printf("Enter an integer: ");
    scanf("%d",&x);
    printf("Value: %d\n", polynomial(x));

    return 0;
}




