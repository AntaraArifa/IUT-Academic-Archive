#include <stdio.h>
void simple(char str[],int n);
int main()
{
    int n,i;
    scanf("%d",&n);
    char str[n],str1[n];
    scanf("%s",str);
    simple(str,n);
    return 0;
}
void simple(char str[],int n)
{int j=0;
int i;
char str1[n];
     for(i=0; i<n; i++)
    {
        if(i>2)
        {
            if(str[i]=='d'&&str[i+1]=='u'&&str[i+2]=='b')
            {
                printf(" ");
                i=i+3;
            }
            str1[j]=str[i];
            printf("%c",str1[j]);
            j++;
        }
    }
}

