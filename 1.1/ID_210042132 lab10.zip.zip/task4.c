#include<stdio.h>
void scan_Array(int arr[], int length)
{
    for(int i=1; i<=length; i++)
    {
        scanf("%d", &arr[i]);
    }
}
void find_Miss(int arr[], int length, int lost)
{
    int pos;
    for(int j=1; j<=length; j++)
    {
        if(arr[j] > lost)
        {
            pos = j;
            break;
        }
    }
    printf("%d", pos);
}


int main()
{
    int n, miss, i, j, pos;
    scanf("%d", &n);
    int arr[n];
    scan_Array(arr, n);
    scanf("%d", &miss);
    find_Miss(arr, n, miss);
}
