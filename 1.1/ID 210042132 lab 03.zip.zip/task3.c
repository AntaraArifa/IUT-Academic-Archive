#include <stdio.h>

int main()
{
    int gs1,grp,pub,item,check;

    printf("Enter ISBN: ");
    scanf("%d -%d -%d -%d -%d", &gs1, &grp, &pub, &item, &check);

    printf( "GS1 prefix: %d\n"
            "Group Identifier: %d\n"
            "Publisher code: %d\n"
            "Item number: %d\n"
            "Check digit: %d\n",
            gs1,grp,pub,item,check);

    return 0;
}
