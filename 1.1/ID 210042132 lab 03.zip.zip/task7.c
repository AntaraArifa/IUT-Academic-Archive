#include <stdio.h>
int main ()
{
    int a,b,c,d,e,f;
    printf("Enter a five digit integer :");
    scanf("%d",&a);

    b=a/10000;
    c=(a-(b*10000))/1000;
    d=((a-(b*10000))-(c*1000))/100;
    e=(((a-(b*10000))-(c*1000))-(d*100))/10;
    f=((((a-(b*10000))-(c*1000))-(d*100))-(e*10))/1;

    printf("The sum is :%d",b+c+d+e+f);
    return 0;
}
