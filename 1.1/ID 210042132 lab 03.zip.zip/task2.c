#include <stdio.h>

int main ()

{
    int itemnumber,m,d,y;
    float unitprice;

    printf("Enter item number: ");
    scanf("%d", &itemnumber);

    printf("Enter unit price: ");
    scanf("%f", &unitprice);

    printf("Enter purchase date (mm/dd/yyyy): ");
    scanf("%d /%d /%d",&m,&d,&y);

    printf("Item Price\tDate\t\tUnit Purchase\n");
    printf("$ %.2f \t%d/%d/%d \t\t%d",unitprice,m,d,y,itemnumber);

    return 0;
}

