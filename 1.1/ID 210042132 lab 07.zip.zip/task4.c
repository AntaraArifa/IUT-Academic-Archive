#include<stdio.h>
int main()
{
    int n,rem,a=0,b=0,c=0;
    scanf("%d",&n);

     int i=1;
     while(i<12)
    {
        rem=n%10;
        if(rem==0)
        {
            a++;
            b=0;
        }

        else
        {
           b++;
           a=0;
        }
        n=n/10;
    if(a>=7 || b>=7)
    {
        c=1;
        break;
    }
    i++;
    }
    if(c==1)
        printf("YES");
    else
        printf("NO");
        return 0;

}




