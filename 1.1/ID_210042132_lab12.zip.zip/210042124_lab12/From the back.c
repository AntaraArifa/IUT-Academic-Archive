
#include<stdio.h>
#define N 500
int main()
{
    int i;
    char ch,arr[N];
    printf("Enter a message: ");
    for(i=0;i<N;i++)
    {
        if((ch=getchar())=='\n'){break;}
        arr[i]=ch;
    }
    printf("Reversal is: ");
    for(i=i-1;i>=0;i--)
    {
        printf("%c",arr[i]);
    }
    printf("\n");
    return 0;
}
