#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
   char m[100] ,rev[100]={0},*p,*q;
   int i,j,l=0;
   gets(m);
   p=&m;
   q=&rev;
   for(i=0;*(p+i)!=NULL;i++)
   {
       l=l+1;
   }
   for(i=l-1,j=0;i>=0;j++)
   {
        *(q+j)=*(p+i);
   }
   if(strcmp(m,rev)==0)
   {
        printf(" palindrome",m);
   }
   else
   {
       printf("not a palindrome",m);
   }
   return 0;

}


