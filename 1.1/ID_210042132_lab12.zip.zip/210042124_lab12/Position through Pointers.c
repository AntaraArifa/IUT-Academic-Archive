#include<stdio.h>
int main()
{

    int n,i,j,temp,tempmin,max,min;
    max=temp=tempmin=0;
    int arr[n];
    min=arr[0];
    for(i=0;i<=n;i++)
    {
        scanf("%d",&arr[i]);
    }
    int *ptr1, *ptr2;
    ptr1 =arr;
    ptr2=arr;
    for(i=1;i<=n;i++)
    {
        if(max <= *ptr1)
        {
            temp = max;
            max = *ptr1;
            *ptr1 = temp;
        }
        ptr1++;
    }
    printf("MAX=%d\n",max);
    for(j=1;j<=n;j++)
    {


        if(min >= *ptr2)
    {
       tempmin +*ptr2;
       *ptr2 = min;
       min = tempmin;
    }
    ptr2++;
    }
    printf("MIN=%d\n",min);
    return 0;


}
