#include <stdio.h>

#define BUF 100

int main()
{
    char *p;
    char input, msg[BUF];

    printf("\nEnter a message: ");
    for (p = &msg[0]; p < &msg[0] + BUF; p++)
    {
        if ((input = getchar()) == '\n')
            break;
        *p = input;
    }

    printf("Reversal is: ");
    for (p = p-1; p >= &msg[0]; p--)
        putchar(*p);
  printf("\n");

  return 0;
}
